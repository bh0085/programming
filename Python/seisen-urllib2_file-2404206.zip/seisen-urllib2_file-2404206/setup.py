from distutils.core import setup

setup(name="urllib2_file",
	version='0.2.1',
	description='urllib2 extension which permit HTTP POST upload',
	author='Fabien SEISEN',
	author_email='fab@seisen.org',
	url='http://fabien.seisen.org/python/',
	py_modules=['urllib2_file'],
	)
