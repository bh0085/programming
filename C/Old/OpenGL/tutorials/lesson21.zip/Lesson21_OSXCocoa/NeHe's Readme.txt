OpenGL Tutorial #21.

Project Name: NeHe's Line, Anti-Aliasing, Timing, Orthographic View and Sound Effect Tutorial

Project Description: Miniature Game Showing Off Multiple Features Of OpenGL

Authors Name: Jeff Molofee (aka NeHe)

Authors Web Site: nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2000 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)

        If you use the code for your own projects please give me credit,
        or mention my web site somewhere in your program or it's docs.
