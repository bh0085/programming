function newsrange(search,startdate,enddate)
%eg:  http://news.google.com/archivesearch?...
%    as_q=apple&...                          %search term
%    num=100&hl=en&btnG=Search+Archives&as_epq=&as_oq=&as_eq=&ned=us&...
%    as_user_ldate=12/01/2008&...            %start data
%    as_user_hdate=12/31/2008&...            %end date
%    lr=&as_src=&as_price=p0&as_scoring=a    %....

%startdate & enddate should be input in the format:
%mm/dd/yyyy

url = ['http://news.google.com/archivesearch?',...
        'as_q=',search,'&',...                          %search term
        'num=100&hl=en&btnG=Search+Archives&as_epq=&as_oq=&as_eq=&ned=us&',...
        'as_user_ldate=',startdate,'&',...            %start data
        'as_user_hdate=',enddate,'&',...            %end date
        'lr=&as_src=&as_price=p0&as_scoring=a' ];  
str = urlread(url);
[splits] = regexp(str,'<tr><td><a[^>]*>','split');

headlines = cell(length(splits) -1,1);
n_related = zeros(length(splits) -1, 1);
for j= 2:length(splits)
    i = j - 1;
    sub=splits{j};
    headsub = regexp(sub,'</a','split');
    title = headsub{1};
    title = regexprep(title,'<[^<]*>','');
    title = regexprep(title,'&[^a-zA-Z]*;','');
    title = regexprep(title,'[^a-zA-Z0-9 ]','');    
    headlines{i} =title;
        
    related = regexp(sub,'All([^a-zA-Z ]*)related','tokens'); 
    if length(related) == 0, n_related(i) = 0 ; 
    else, n_related(i) = str2double(related{1});
    end
end

display = 1
if display
    for i = 1:length(headlines)
        disp([sprintf('%i',n_related(i)),headlines{i}]);
    end
end

1